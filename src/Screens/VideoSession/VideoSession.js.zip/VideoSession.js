import React, { useEffect, useState } from 'react';
import { Text, View } from 'react-native';

import AgoraUIKit from 'agora-rn-uikit';

import { createAgoraRtcEngine } from 'react-native-agora';

import HeaderComp from '../../Components/HeaderComp';
import WrapperContainer from '../../Components/WrapperContainer';
import imagesPath from '../../constants/imagesPath';
import { moderateScale } from '../../styles/responsiveSize';
import commonStyles from '../../styles/commonStyles';
import { createAgoraTokenApi } from '../../redux/reduxActions/chatActions';
import { ApiError, showError } from '../../utils/helperFunctions';
import { Loader } from '../../Components/Loader';

const VideoSession = (props) => {
    const { navigation, route } = props;

    const [prevData, setPrevData] = useState(route?.params?.prevData)

    const [isLoading, setLoading] = useState(true)
    const [videoCall, setVideoCall] = useState(false);
    const [connectionData, setConnectionData] = useState({})

    useEffect(() => {
        if (videoCall) {
            setLoading(false)
        }
    }, [videoCall])

    useEffect(() => {
        _getAgoraConnectionData()
    }, [])

    const _getAgoraConnectionData = () => {
        let apiData = {
            user_id: prevData?.id
        }
        createAgoraTokenApi(apiData).then(res => {
            console.log(res, "sslkslsklsksl");
            setConnectionData({
                // appId: res?.data?.app_id,
                // channel: res?.data?.channel_name,
                // token: res?.data?.rtc_token,

                appId: "2601d3662c2447839c95b0d2ea6161ff",
                channel: "testvidcall",
                token: "007eJxTYIi9carEM64t7AcX78QVSn8f/TN9d9Hu3Ab9OW0ftBavf/1FgcHIzMAwxdjMzCjZyMTE3MLYMtnSNMkgxSg10czQzDAtTV1eJaUhkJFh//WlrIwMEAjiczOUpBaXlGWmJCfm5DAwAADvPiRZ"
            })
            setTimeout(() => {
                setVideoCall(true)
            }, 1000);
        }).catch((error) => {
            showError(ApiError(error))
        })
    }

    // const connectionData = {
    //     appId: '2601d3662c2447839c95b0d2ea6161ff',
    //     channel: 'sssss',
    //     token: "007eJxTYLATDH6l9PCw4zmdv11/d+z/7hbrab0npyctvvp8csvmxZUKDEZmBoYpxmZmRslGJibmFsaWyZamSQYpRqmJZoZmhmlpK8VFUhoCGRk+BGsxMEIhiM/KUAwCDAwAqp8gIA==",
    // };

    const rtcCallbacks = {
        EndCall: () => setVideoCall(false),
    };
    return (
        <WrapperContainer>
            <HeaderComp
                leftIcon={imagesPath.ic_back}
                onPressBack={() => navigation.goBack()}
                centerText={prevData?.first_name}
            />

            {/* <Text style={commonStyles.font_22_SemiBold}>{connectionData?.token}</Text> */}

            {videoCall ? (
                <AgoraUIKit
                    connectionData={connectionData}
                    rtcCallbacks={rtcCallbacks}
                    settings={{
                        // dual: true,
                        // mode: 1
                    }}
                    rtmCallbacks={(props) => console.log(props, "rtmCallbacks")}
                />
            ) :
                <></>
                //  (
                //     <Text onPress={() => setVideoCall(true)} style={{
                //         ...commonStyles.font_16_bold
                //     }}>Start Call</Text>
                // )
            }
            <Loader isLoading={isLoading} />
        </WrapperContainer>
    )
};

export default VideoSession;
